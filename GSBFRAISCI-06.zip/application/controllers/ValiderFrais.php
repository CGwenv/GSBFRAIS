<?php
/**
 * Class : Contrôleur permettant de visualiser l'état des fiches de frais d'un visiteur préalablement connecté.   
 * Permet au visiteur de :
 *  - choisir une fiche de frais en fonction du mois
 *  - visualiser l'état de la fiche selectionnée
 *  - visualiser les frais forfaitaires et hors-forfaits de la fiche selectionnée
 */
class ValiderFrais extends CI_Controller {
    private $id_mois;
    private $id_visiteur;
/**
 * Constructeur   
 * si l'utilisateur n'est pas connecté il est redirigé vers le contrôleur de connexion.
 * sinon :
 *  - chargement du modèle, des helpers et bibliothèques
 *  - l'id visiteur est initalisé à celui du visiteur connecté
 *  - l'id du mois n'est pas initialisé (il le sera en fonction des actions de l'utilisateur)
 */
    public function __construct()
    {
        parent::__construct();
        $this->load->library('gsb_lib');
        $this->load->helper('url_helper');
        if( ! $this->gsb_lib->est_connecte() ){
            redirect(site_url('Connexion'));
        }
        else{
            $this->load->model('gsb_model');
            $this->load->helper('form_helper');
            $this->load->library('session');
        }
    }

/**
 * méthode action par défaut : le comptable accède à ce contrôleur en ayant cliqué sur le menu correspondant.  
 *  - usage : <application base url>/ValiderFrais ou <application base url>/ValiderFrais/index
 */
    public function index(){
        $this->id_mois = null;
        $this->id_visiteur = null;
        $this->commun();
    }

/**
 * méthode action : le comptable vient de choisir une fiche dans la liste déroulante.
 *  - usage : <application base url>/ValiderFrais/selectionner_fiche
 */ 
    public function selectionner_fiche(){
        // "a131-202107"
        $id_fiche = $this->input->post('lstFiches');
        list($this->id_visiteur, $this->id_mois) = explode("-", $id_fiche);
        $this->commun();
    }

    
    /**
     * méthode action : actualisation fraisforfait 
     *  - usage : <application base url>/ValiderFrais/maj_fraisforfait
     */ 
    public function maj_fraisforfait($id_fiche){
        list($id_visiteur, $id_mois) = explode("-", $id_fiche);
        $this->gsb_model->maj_frais_forfait($id_visiteur, $id_mois);
        $this->info = "Les modifications des frais hors forfait ont bien été effectuées";
        $this->commun();
    }

	/**
     * méthode action : report fraisforfait 
     *  - usage : <application base url>/ValiderFrais/reporter_fraishorsforfait
     */ 
    public function reporter_fraishorsforfait($id_frais){
        $this->gsb_model->report_frais_horsforfait($id_frais);
        $this->info = "Le report de la fiche a bien été effectuées";
        $this->commun();
    }

    /**
     * méthode action : le visiteur vient de cliquer sur l'icone permettant de supprimer un élément hors forfait.  
     *  - usage : <application base url>/Validerfrais/supprimer_fraishorsforfait/<id_fraishorsforfait>
     *  - TODO : securiser la suppression
     */
    public function supprimer_fraishorsforfait($id_fraishorsforfait){ 
        $this->info = $this->gsb_model->refus_fraishorsforfait($id_fraishorsforfait);
        $this->commun();
    }

/**
 * méthode action : le comptable vient valider une fiche.
 *  - usage : <application base url>/ValiderFrais/valider_fiche
 */ 
    public function valider_fiche($id_fiche){
        list($id_visiteur, $id_mois) = explode("-", $id_fiche);
        $this->gsb_model->maj_etat_fiche_frais($id_visiteur, $id_mois, "VA");
        //la fiche a été modifiée en état RB et va disparaitre de la liste déroulante
        
        $this->info = "La fiche a été validée";

        //la nouvelle fiche selectionnée sera la première de la liste
        $this->id_mois = null;
        $this->id_visiteur = null;
        $this->commun();
    }

/**
 * Traitement commun au contrôleur ValiderFrais.
 */
    private function commun(){
        //infos générales page
        $this->load->view('structures/v_page_entete');
        $this->load->view('v_sommaire');
        $data['titre'] = "Valider fiches de frais";
        $this->load->view('structures/v_contenu_entete', $data);

        //gestion des notifications
        if( isset($this->info) ){
            $data['info'] = $this->info;
            $this->load->view('structures/v_notification', $data);
        }

        //récupération des fiches de frais dans l'état CL
        $les_fiches = $this->gsb_model->get_fiches_etat('CL');
        if(count($les_fiches) == 0){
            $data['info'] = "Toutes les fiches de frais ont été validées";
            $this->load->view('structures/v_notification', $data);
        }
        else {
            if ( ! isset($this->id_mois) ){  // si aucun mois choisi, on prend par défaut le premier mois dans la liste
                $this->id_mois = $les_fiches[0]['mois'];
                $this->id_visiteur = $les_fiches[0]['idVisiteur'];
            }
            // echo $this->id_visiteur." ".$this->id_mois;

        //gestion liste déroulante
            $options = []; // création d'un tableau contenant les 'options' de la liste 'select'
            // var_dump($les_fiches);
            foreach ($les_fiches as $une_fiche){
               $libelle = $une_fiche['prenom']." ".strtoupper($une_fiche['nom'])."  - ".$this->gsb_lib->get_nom_mois($une_fiche['numMois'])." ".$une_fiche['numAnnee'];
               $cle = $une_fiche['idVisiteur']."-".$une_fiche['mois'];
               $options[$cle] = $libelle; // <option value="a131-202107">Prenom NOM - Juillet 2021</option>
            }
            // var_dump($options);
            $data['lst_contenu'] = $options;
            $fiche_selectionne = $this->id_visiteur."-".$this->id_mois;
            $data['lst_select'] = $fiche_selectionne;  // correspondant à l'élément selectionné dans la liste (attribut selected pour un option)
            $data['lst_action'] = 'ValiderFrais/selectionner_fiche'; //action effectuée par le formulaire un fois soummis
            $data['lst_id'] = 'lstFiches';
            $data['lst_label'] = 'Fiches frais';
            $data['sc_titre'] = 'Fiches validées à sélectionner :';
            $this->load->view('structures/v_souscontenu_entete', $data);
            $this->load->view('templates/v_liste_deroulante', $data);
            $this->load->view('structures/v_souscontenu_pied');

            //gestion de la fiche
            $un_visiteur = $this->gsb_model->get_detail_visiteur($this->id_visiteur);
            $nomPrenom = $un_visiteur['prenom']." ".strtoupper($un_visiteur['nom']);
            $num_annee = substr($this->id_mois, 0, 4);
            $num_mois = substr($this->id_mois, 4, 2);
            $date_titre = $this->gsb_lib->get_nom_mois($num_mois)." ".$num_annee;
            $data['sc_titre'] = "Fiche de frais - $nomPrenom de $date_titre"; 
            $this->load->view('structures/v_souscontenu_entete', $data);

            //gestion zone Etat
            $data['fiche'] = $this->gsb_model->get_les_infos_ficheFrais($this->id_visiteur, $this->id_mois);
            $this->load->view('v_etat_fiche', $data);

            //gestion des éléments forfaitisés
            $data['ff'] = $this->gsb_model->get_les_frais_forfait($this->id_visiteur, $this->id_mois);
            $data['action_edit'] = 'ValiderFrais/maj_fraisforfait/'.$fiche_selectionne;
            $data['value'] = 'Actualiser';
            $this->load->view('v_fraisforfait_edit', $data);

            //gestion frais hors forfaits
            $data['fhf'] = $this->gsb_model->get_les_frais_hors_forfait($this->id_visiteur, $this->id_mois);
            $data['refus_action'] = "ValiderFrais/supprimer_fraishorsforfait"; 
			$data['reportfhf'] = $this->gsb_model->get_les_frais_hors_forfait($this->id_visiteur, $this->id_mois);
            $data['report_action'] = "ValiderFrais/reporter_fraishorsforfait/"; 
            $this->load->view('v_fraishorsforfait_table_valid', $data);

            $data['action'] = "ValiderFrais/valider_fiche/";
            $data['value'] = "Valider la fiche";
            $this->load->view('v_action_fiche', $data);

        }  
        
        //fin de la fiche
        $this->load->view('structures/v_souscontenu_pied');

        //fin du contenu et de la page
        $this->load->view('structures/v_page_pied');
    }
}
