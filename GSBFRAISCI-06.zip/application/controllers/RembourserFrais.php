<?php
/**
 * Class : Contrôleur permettant de visualiser l'état des fiches de frais d'un visiteur préalablement connecté.   
 * Permet au visiteur de :
 *  - choisir une fiche de frais en fonction du mois
 *  - visualiser l'état de la fiche selectionnée
 *  - visualiser les frais forfaitaires et hors-forfaits de la fiche selectionnée
 */
class RembourserFrais extends CI_Controller {

    private $id_mois;
    private $id_visiteur;
    private $info;

/**
 * Constructeur   
 * si l'utilisateur n'est pas connecté il est redirigé vers le contrôleur de connexion.
 * sinon :
 *  - chargement du modèle, des helpers et bibliothèques
 *  - l'id visiteur est initalisé à celui du visiteur connecté
 *  - l'id du mois n'est pas initialisé (il le sera en fonction des actions de l'utilisateur)
 */
    public function __construct()
    {
        parent::__construct();
        $this->load->library('gsb_lib');
        $this->load->helper('url_helper');
        if( ! $this->gsb_lib->est_connecte() ){
            redirect(site_url('Connexion'));
        }
        else{
            $this->load->model('gsb_model');
            $this->load->helper('form_helper');
            $this->load->library('session');
        }
    }

/**
 * méthode action par défaut : le comptable accède à ce contrôleur en ayant cliqué sur le menu correspondant.  
 *  - usage : <application base url>/RembourserFrais ou <application base url>/RembourserFrais/index
 */
    public function index(){
        $this->id_mois = null;
        $this->id_visiteur = null;
        $this->commun();
    }

/**
 * méthode action : le comptable vient de choisir une fiche dans la liste déroulante.
 *  - usage : <application base url>/RembourserFrais/selectionner_fiche
 */ 
    public function selectionner_fiche(){
        // "a131-202107"
        $id_fiche = $this->input->post('lstFiches');
        list($this->id_visiteur, $this->id_mois) = explode("-", $id_fiche);
        $this->commun();
    }

/**
 * méthode action : le comptable vient rembourser une fiche.
 *  - usage : <application base url>/RembourserFrais/rembourser_fiche
 */ 
    public function rembourser_fiche($id_fiche){
        list($id_visiteur, $id_mois) = explode("-", $id_fiche);
        $this->gsb_model->maj_etat_fiche_frais($id_visiteur, $id_mois, "RB");
        //la fiche a été modifiée en état RB et va disparaitre de la liste déroulante
        
        $this->info = "La fiche a été remboursée";

        //la nouvelle fiche selectionnée sera la première de la liste
        $this->id_mois = null;
        $this->id_visiteur = null;
        $this->commun();
    }


/**
 * Traitement commun au contrôleur RembourserFrais.
 */
    private function commun(){
        //infos générales page
        $this->load->view('structures/v_page_entete');
        $this->load->view('v_sommaire');
        $data['titre'] = "Remboursement des frais";
        $this->load->view('structures/v_contenu_entete', $data);
        
        //gestion des notifications
        if( isset($this->info) ){
            $data['info'] = $this->info;
            $this->load->view('structures/v_notification', $data);
        }

        //récupération des fiches de frais dans l'état VA
        $les_fiches = $this->gsb_model->get_fiches_etat('VA');
        if(count($les_fiches) == 0){
            $data['info'] = "Toutes les fiches de frais ont été remboursées";
            $this->load->view('structures/v_notification', $data);
        }
        else{
            if ( ! isset($this->id_mois) ){  // si aucun mois choisi, on prend par défaut le premier mois dans la liste
                $this->id_mois = $les_fiches[0]['mois'];
                $this->id_visiteur = $les_fiches[0]['idVisiteur'];
            }
            // echo $this->id_visiteur." ".$this->id_mois;

        //gestion liste déroulante
            $options = []; // création d'un tableau contenant les 'options' de la liste 'select'
            // var_dump($les_fiches);
            foreach ($les_fiches as $une_fiche){
               $libelle = $une_fiche['prenom']." ".strtoupper($une_fiche['nom'])."  - ".$this->gsb_lib->get_nom_mois($une_fiche['numMois'])." ".$une_fiche['numAnnee'];
               $cle = $une_fiche['idVisiteur']."-".$une_fiche['mois'];
               $options[$cle] = $libelle; // <option value="a131-202107">Prenom NOM - Juillet 2021</option>
            }
            // var_dump($options);
            $data['lst_contenu'] = $options;
            $fiche_selectionne = $this->id_visiteur."-".$this->id_mois;
            $data['lst_select'] = $fiche_selectionne;  // correspondant à l'élément selectionné dans la liste (attribut selected pour un option)
            $data['lst_action'] = 'RembourserFrais/selectionner_fiche'; //action effectuée par le formulaire un fois soummis
            $data['lst_id'] = 'lstFiches';
            $data['lst_label'] = 'Fiches';
            $data['sc_titre'] = 'Fiches à sélectionner :';
            $this->load->view('structures/v_souscontenu_entete', $data);
            $this->load->view('templates/v_liste_deroulante', $data);
            $this->load->view('structures/v_souscontenu_pied');

            //gestion de la fiche
            $un_visiteur = $this->gsb_model->get_detail_visiteur($this->id_visiteur);
            $nomPrenom = $un_visiteur['nom']." ".$un_visiteur['prenom'];
            $num_annee = substr($this->id_mois, 0, 4);
            $num_mois = substr($this->id_mois, 4, 2);
            $date_titre = $this->gsb_lib->get_nom_mois($num_mois)." ".$num_annee;
            $data['sc_titre'] = "Fiche de frais du mois de $date_titre de $nomPrenom :"; 
            $this->load->view('structures/v_souscontenu_entete', $data);

            //gestion zone Etat
            $data['fiche'] = $this->gsb_model->get_les_infos_ficheFrais($this->id_visiteur, $this->id_mois);
            $this->load->view('v_etat_fiche', $data);
        
            //gestion frais forfaits
            $data['ff'] = $this->gsb_model->get_les_frais_forfait($this->id_visiteur, $this->id_mois);
            $this->load->view('v_fraisforfait_table', $data);
        
            //gestion frais hors forfaits
            $data['fhf'] = $this->gsb_model->get_les_frais_hors_forfait($this->id_visiteur, $this->id_mois);
            $this->load->view('v_fraishorsforfait_table', $data);

            //gestion du bouton action : Rembourser
            // var_dump($data);
            $data['action'] = "RembourserFrais/rembourser_fiche";
            $data['value'] = "Rembourser la fiche";
            $this->load->view('v_action_fiche', $data);
        
            //fin de la fiche
            $this->load->view('structures/v_souscontenu_pied');

             //fin du contenu et de la page
             $this->load->view('structures/v_page_pied');
        }
    }
}