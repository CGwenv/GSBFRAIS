<div class ="info">
	<?= $info; ?>
</div>
