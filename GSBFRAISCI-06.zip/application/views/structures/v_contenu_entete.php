    <div id="contenu">
	    <h2><?= $titre ?></h2>
