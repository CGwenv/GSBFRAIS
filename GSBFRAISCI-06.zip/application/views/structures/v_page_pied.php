        </div> <!-- #contenu -->
    </div> <!-- #page -->
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>
</html>
