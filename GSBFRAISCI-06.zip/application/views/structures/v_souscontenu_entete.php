<div id="sousContenu">
	<h3><?= $sc_titre ?></h3> 
