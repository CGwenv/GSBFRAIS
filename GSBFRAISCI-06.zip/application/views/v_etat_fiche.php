<div id="etatMontant">
    <div id="etat" class="<?= $fiche['idEtat'];?>">
        <?= $fiche['libelleEtat']?> depuis le <?= $this->gsb_lib->date_vers_francais($fiche['dateModif']) ?> 
    </div>
    <div id="montantValide">
        Montant validé
        <div><?= $this->gsb_lib->format_montant($fiche['montantValide']) ?> &#8364;</div>
    </div>
</div>	
