 
<div>
    <?= img('/assets/images/trvx.gif', FALSE ,'width="300"'); ?>
</div>
