<?php
    echo form_open(site_url("$action/$lst_select")); 
        echo '<div class="piedFormLarge">';
            echo '<p>';
                $data = [	'type' 	=> 'submit', 
                            'class'	=> 'bouton bouton-large',
                            'value' => $value,
                            'size'  => '50' 
                        ];
                echo form_input($data);
            echo '</p>';
        echo '</div>';
    echo form_close();  