    <h4>Descriptif des éléments hors forfait -<?= $fiche['nbJustificatifs'] ?> justificatifs reçus -</h4>
	<table class="listeLegere">
		<tr>
			<th class="date">Date</th>
			<th class="libelle">Libellé</th>
            <th class="montant">Montant</th>                
        </tr>
<?php   foreach ($fhf as $unfhf): 
            $date = $this->gsb_lib->date_vers_francais($unfhf['date']);
            $libelle = $unfhf['libelleFraisHorsForfait'];
            $montant = $this->gsb_lib->format_montant($unfhf['montant']); ?>  
            <tr>
                <td><?= $date ?></td>
                <td class="libelle"><?= $this->security->xss_clean($libelle) ?></td>
                <td class="montant"><?= $montant ?></td>
            </tr>
<?php   endforeach; ?>
	</table>
	&nbsp;
