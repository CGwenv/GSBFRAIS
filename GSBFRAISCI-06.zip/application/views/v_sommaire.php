<?php
	$menus = $this->gsb_lib->get_menus($this->session->type);
?>
    <div id="menuGauche">
		<div id="infosUtil">
			<div id="user">
				<img src="<?= site_url('../assets/images/UserIcon.png') ?>" />
			</div>
			<div id="infos">
                <h2><?= $this->session->prenom." ".strtoupper($this->session->nom)  ?> </h2>
				<h3><?= $this->session->libelleType ?></h3>  
			</div>
			<ul class="menuList">
				<li class="smenu">
                    <?= anchor('Connexion/deconnexion', 'Déconnexion', 'title="Se déconnecter"'); ?>
				</li>
			</ul>    
		</div>  
        <ul id="menuPrincipal" class="menuList">
<?php		foreach($menus as $menu){
				echo '<li class="smenu">';
                	echo anchor($menu['uc'], $menu['text'], 'title="'.$menu['title'].'"');
				echo '</li>';
	 		}
?>
        </ul>
    </div>

	
