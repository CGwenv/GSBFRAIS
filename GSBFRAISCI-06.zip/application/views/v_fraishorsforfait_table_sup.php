
<h4>Descriptif des éléments hors forfait</h4>
    <table class="listeLegere">
        <tr>
            <th class="date">Date</th>
            <th class="libelle">Libellé</th>
            <th class="montant">Montant</th>     
            <th class="action">&nbsp;</th>           
        </tr>
		<?php foreach($fhf as $unfhf) : 
			$date = $this->gsb_lib->date_vers_francais($unfhf['date']);
			$libelle = $unfhf['libelleFraisHorsForfait'];
			$montant = $this->gsb_lib->format_montant($unfhf['montant']); 
			$id = $unfhf['idFraisHorsForfait'] ?>
			<tr>
				<td><?= $date ?></td>
				<td class="libelle"><?= $this->security->xss_clean($libelle) ?></td>
				<td class="montant"><?= $montant ?></td>
				<td>
					
					<a 	href="<?= site_url('GererFrais/supprimer_fraishorsforfait/'.$id) ?>" 
						onclick="return confirm('Voulez-vous vraiment supprimer ce frais ?');">
						<img src="<?= site_url('../assets/images/delete.png') ?> " />
					</a>
				</td>
			</tr>
		<?php endforeach ?>
    </table>
    &nbsp;
