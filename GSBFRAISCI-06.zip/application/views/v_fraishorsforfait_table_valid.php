<h4>Descriptif des éléments hors forfait -<?= $fiche['nbJustificatifs'] ?> justificatifs reçus -</h4>
	<table class="listeLegere">
		<tr>
			<th class="date">Date</th>
			<th class="libelle">Libellé</th>
            <th class="montant">Montant</th>     
            <th class="action">&nbsp;</th> 
            <th class="action">&nbsp;</th>      
        </tr>
<?php   foreach ($fhf as $unfhf): 
            $date = $this->gsb_lib->date_vers_francais($unfhf['date']);
            $libelle = $unfhf['libelleFraisHorsForfait'];
            $montant = $this->gsb_lib->format_montant($unfhf['montant']);
            $id = $unfhf['idFraisHorsForfait'];
            $etat = $unfhf['etat']
            ?> 
            <tr>
                <td><?= $date ?></td>
                <td class="libelle"><?= $this->security->xss_clean($libelle) ?></td>
                <td class="montant"><?= $montant ?></td>
                <td>
                    <?php if($etat == 1) { ?>
                    	<a href="#" onclick="confirm_gsb('<?= $id ?>', '<?= site_url('ValiderFrais/supprimer_fraishorsforfait/') + $id ?>', 'Refuser un Frais', 'Voulez-vous vraiment refuser le frais ?', 'warning', true);">❌</a>
                    <?php } else { ?>
                    	<a href="#" onclick="confirm_gsb('<?= $id ?>', '<?= site_url('ValiderFrais/supprimer_fraishorsforfait/') + $id ?>', 'Retablir un Frais', 'Voulez-vous vraiment retablir le frais ?', 'warning', true);">✔️</a>
                    <?php } ?>
                </td>
                <td class="date">
                    <a 	href="#" onclick="confirm_gsb('<?= $id ?>', '<?= site_url($report_action.$id) ?>', 'Reporter un Frais', 'Voulez-vous vraiment reporter le frais ?', 'warning', true);">📅</a>
                </td>
            </tr>
<?php   endforeach; ?>
	</table>
	&nbsp;

<script type="text/javascript">
	function confirm_gsb(id, url, title, text, icon, dangerMode){
		swal({   
		title: title,
		text: text,
		icon: icon,
		dangerMode: dangerMode,
		
		closeOnConfirm: false,
		closeOnCancel: false,
		buttons: ['Annuler',"Oui"], 
		})
		
		.then((willDelete) => {
			if (willDelete) {
				window.location.href = url;
			}
		});
	}
</script>
