<?php
class Gsb_model extends CI_Model
{
    /** 
     * Classe d'accès aux données 
     * Hérite de la classe CI_Model
     */

    public function __construct()
    {
        $this->load->database();
    }

    /**
     * Retourne les informations d'un utilisateur
     * @param $login 
     * @param $mdp
     * @return tableau associatif contenant l'id, le nom, le prénom, le login et le type
     */
    public function get_infos_utilisateur($login, $mdp)
    {
        $this->db->select(' idUtilisateur, 
                            nom, 
                            prenom, 
                            login,
                            utilisateur.idTypeUtilisateur,
                            libelleTypeUtilisateur');
        $this->db->from('utilisateur');
        $this->db->join('typeutilisateur', 'utilisateur.idTypeUtilisateur =  typeutilisateur.idTypeUtilisateur');
        $this->db->where('login', $login);
        $this->db->where('mdp', $mdp);
        $query = $this->db->get();
        return $query->row_array(); //fetch
    }

    /**
     * Retourne les informations d'un visiteur
     * @param $id 
     * @return tableau associatif contenant toutes les informations d'un visiteur
     */
    public function get_detail_visiteur($id)
    {
        $this->db->select('nom, prenom');
        $this->db->from('visiteur');
        $this->db->where('idVisiteur', $id);
        $query = $this->db->get();
        return $query->row_array();
    }

    /**
     * Retourne les mois pour lesquel un visiteur a une fiche de frais
     * @param $idVisiteur 
     * @return tableau des mois (au format -aaaamm-), de l'année (au format -aaaa-) et du mois (au format -mm-) correspondants 
     * */
    public function get_les_mois_disponibles($idVisiteur)
    {
        $this->db->select(' mois, 
                            SUBSTR(fichefrais.mois, 1, 4) AS numAnnee, 
                            SUBSTR(fichefrais.mois, 5) AS numMois');
        $this->db->from('fichefrais');
        $this->db->where('idVisiteur', $idVisiteur);
        $this->db->order_by('mois', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }

    /**
     * Retourne les informations d'une fiche de frais d'un visiteur pour un mois donné
     * @param $idVisiteur 
     * @param $mois (sous la forme aaaamm)
     * @return tableau asoociatif avec des champs de jointure entre une fiche de frais et la ligne d'état 
     */
    public function get_les_infos_ficheFrais($idVisiteur, $mois)
    {
        $this->db->select(' fichefrais.idEtat, 
                            fichefrais.dateModif, 
                            fichefrais.nbJustificatifs, 
                            fichefrais.montantValide, 
                            etat.libelleEtat');
        $this->db->from('fichefrais');
        $this->db->join('etat', 'fichefrais.idEtat =  etat.idEtat');
        $this->db->where('fichefrais.idVisiteur', $idVisiteur);
        $this->db->where('fichefrais.mois', $mois);
        $query = $this->db->get();
        return $query->row_array();
    }

    /**
     * Retourne toutes les lignes de frais forfait d'un visiteur pour un mois donné 
     * @param $idVisiteur 
     * @param $mois sous la forme aaaamm
     * @return tableau associatif contenant l'id, le libelle et la quantité pour chaque frais forfait  
     */
    public function get_les_frais_forfait($idVisiteur, $mois)
    {
        $this->db->select(' fraisforfait.idFraisForfait, 
                            fraisforfait.libelleFraisForfait, 
                            lignefraisforfait.quantite');
        $this->db->from('lignefraisforfait');
        $this->db->join('fraisforfait', 'fraisforfait.idFraisForfait = lignefraisforfait.idFraisForfait');
        $this->db->where('lignefraisforfait.idVisiteur', $idVisiteur);
        $this->db->where('lignefraisforfait.mois', $mois);
        $this->db->order_by('lignefraisforfait.idFraisForfait', 'ASC');
        $query = $this->db->get();
        return $query->result_array();
    }

    /**
     * Retourne toutes les lignes de frais hors forfait d'un visiteur pour un mois donné

     * @param $idVisiteur 
     * @param $mois sous la forme aaaamm
     * @return tableau associatif contenant tous les champs des lignes de frais hors forfait  
     */
    public function get_les_frais_hors_forfait($idVisiteur, $mois)
    {
        $this->db->from('lignefraishorsforfait');
        $this->db->where('idVisiteur', $idVisiteur);
        $this->db->where('mois', $mois);
        $query = $this->db->get();
        return $query->result_array();
    }

	/**
     * Retourne toutes les lignes de frais hors forfait d'un visiteur pour un mois donné

     * @param $idVisiteur 
     * @param $mois sous la forme aaaamm
     * @return tableau associatif contenant tous les champs des lignes de frais hors forfait  
     */
    public function get_le_frais_hors_forfait($id)
    {
        $this->db->from('lignefraishorsforfait');
        $this->db->where('idFraisHorsForfait', $id);
        $query = $this->db->get();
        return $query->result_array();
    }

    /**
     * Teste si un visiteur possède une fiche de frais pour le mois passé en argument
     * @param $idVisiteur 
     * @param $mois sous la forme aaaamm
     * @return vrai ou faux 
     */
    public function est_premier_frais_mois($idVisiteur, $mois)
    {
        $this->db->select('count(*) AS nblignesfrais');
        $this->db->from('fichefrais');
        $this->db->where('fichefrais.idVisiteur', $idVisiteur);
        $this->db->where('fichefrais.mois', $mois);
        $query = $this->db->get();
        $laLigne = $query->row_array();
        $ok = ($laLigne['nblignesfrais'] === "0");
        return $ok;
    }

    /**
     * Retourne le dernier mois en cours d'un visiteur
     * @param $idVisiteur 
     * @return le mois sous la forme aaaamm
     */
    public function dernier_mois_saisi($idVisiteur)
    {
        $this->db->select('max(mois) AS dernierMois');
        $this->db->from('fichefrais');
        $this->db->where('fichefrais.idVisiteur', $idVisiteur);
        $query = $this->db->get();
        $laLigne = $query->row_array();
        return $laLigne['dernierMois'];
    }

    /**
     * Retourne tous les id de la table FraisForfait
     * @return tableau associatif des  idFraisForfait
     */
    public function get_les_id_frais_forfait()
    {
        $this->db->select('idFraisForfait');
        $this->db->from('fraisforfait');
        $this->db->order_by('idFraisForfait');
        $query = $this->db->get();
        return $query->result_array();
    }

    /**
     * Crée une nouvelle fiche de frais et les lignes de frais au forfait pour un visiteur et un mois donnés
     * récupère le dernier mois en cours de traitement, met à 'CL' son champs idEtat, crée une nouvelle fiche de frais
     * avec un idEtat à 'CR' et crée les lignes de frais forfait de quantités nulles 
     * @param $idVisiteur 
     * @param $mois sous la forme aaaamm
     */
    public function cree_nouvelles_lignes_frais($idVisiteur, $mois)
    {
        // mise a jour de la dernière fiche
        $dernierMois = $this->dernier_mois_saisi($idVisiteur);
        $laDerniereFiche = $this->get_les_infos_ficheFrais($idVisiteur, $dernierMois);
        if ($laDerniereFiche['idEtat'] == 'CR') {
            $this->maj_etat_fiche_frais($idVisiteur, $dernierMois, 'CL');
        }

        // création de la nouvelle fiche
        $data = array(
            'idVisiteur' => $idVisiteur,
            'mois' => $mois,
            'nbJustificatifs' => 0,
            'montantValide' => 0,
            'dateModif' => date('Y-m-d'),
            'idEtat' => 'CR'
        );
        $this->db->insert('fichefrais', $data);

        // initialisation des frais fortfaits à 0
        $lesIdFraisForfait = $this->get_les_id_frais_forfait();
        foreach ($lesIdFraisForfait as $unIdFraisForfait) {
            $data = array(
                'idVisiteur' => $idVisiteur,
                'mois' => $mois,
                'idFraisForfait' => $unIdFraisForfait['idFraisForfait'],
                'quantite' => 0
            );
            $this->db->insert('lignefraisforfait', $data);
        }
    }

    /**
     * Modifie l'état et la date de modification d'une fiche de frais
     * Modifie le champ idEtat et met la date de modif à aujourd'hui
     * @param $idVisiteur 
     * @param $mois sous la forme aaaamm
     */
    public function maj_etat_fiche_frais($idVisiteur, $mois, $etat)
    {
        $data = array(
            'idEtat' => $etat,
            'dateModif' => date('Y-m-d')
        );
        $where = array(
            'idVisiteur' => $idVisiteur,
            'mois' => $mois
        );
        $this->db->update('fichefrais', $data, $where);
    }

    /**
     * Met à jour la table ligneFraisForfait pour un visiteur et un mois donné en enregistrant les nouveaux montants
     * @param $idVisiteur 
     * @param $mois sous la forme aaaamm
     * @param $lesFrais tableau associatif de clé idFrais et de valeur la quantité pour ce frais
     */
    public function maj_frais_forfait($idVisiteur, $mois, $lesFrais)
    {
        echo $idVisiteur.' '.$mois;
        $lesIdFraisForfait = array_keys($lesFrais);
        foreach ($lesIdFraisForfait as $unIdFraisForfait) {
            $qte = $lesFrais[$unIdFraisForfait];
            $data = array('quantite' => $qte);
            $where = array(
                'idVisiteur' => $idVisiteur,
                'mois' => $mois,
                'idFraisForfait' =>  $unIdFraisForfait
            );
            $this->db->update('lignefraisforfait', $data, $where);
        }
    }

	/**
     * Met à jour la table ligneFraisForfait pour un visiteur et un mois donné en enregistrant les nouveaux montants
     * @param $idVisiteur 
     * @param $mois sous la forme aaaamm
     * @param $lesFrais tableau associatif de clé idFrais et de valeur la quantité pour ce frais
     */
    public function report_frais_horsforfait($idfrais)
    {
		$frais = $this->get_le_frais_hors_forfait($idfrais);
		$idVisiteur = $frais[0]['idVisiteur'];
		$idMois = $frais[0]['mois'];
		$date = $frais[0]['date'];

		$num_annee = substr($idMois, 0, 4);
		$num_mois = substr($idMois, 4, 2);
		$day_date = substr($date, 8, 2);

		$new_mois = intval($num_mois+1);
		$new_date = $num_annee.'-'.sprintf("%02d",$new_mois).'-'.$day_date;

		if($new_mois > 12){ $new_mois = "01"; $num_annee++; }

        if (empty($this->get_les_infos_ficheFrais($idVisiteur, $num_annee.sprintf("%02d", $new_mois)))) {
            $dataF = array(
            'idVisiteur' => $idVisiteur,
            'mois' => $num_annee.sprintf("%02d", $new_mois),
            'nbJustificatifs' => 0,
            'montantValide' => 0,
            'dateModif' => date('Y-m-d'),
            'idEtat' => 'CR'
        	);
            $this->db->insert('fichefrais', $dataF);
        }

		$data = array(
			'mois' => $num_annee.sprintf("%02d",$new_mois),
			'date' => $new_date
		);
		$where = array(
			'idVisiteur' => $idVisiteur,
			'mois' => $idMois,
			'idFraisHorsForfait' =>  $idfrais
		);
			
        $this->db->update('lignefraishorsforfait', $data, $where);
    }

    /**
     * Supprime le frais hors forfait dont l'id est passé en argument
     * @param $idFrais 
     */
    public function supprimer_frais_hors_forfait($idFrais)
    {
        $where = array('idFraisHorsForfait' => $idFrais);
        $this->db->delete('lignefraishorsforfait', $where);
    }

    /**
     * Crée un nouveau frais hors forfait pour un visiteur un mois donné à partir des informations fournies en paramètre
     * @param $idVisiteur 
     * @param $mois sous la forme aaaamm
     * @param $libelle : le libelle du frais
     * @param $date : la date du frais au format français jj/mm/aaaa
     * @param $montant : le montant
     */
    public function creer_nouveau_frais_hors_forfait($idVisiteur, $mois, $libelle, $date, $montant)
    {
        $data = array(
            'idVisiteur' => $idVisiteur,
            'mois' => $mois,
            'libelleFraisHorsForfait' => $this->security->xss_clean($libelle),
            'date' =>  $date,
            'montant' => $montant
        );
        $this->db->insert('lignefraishorsforfait', $data);
    }

    /**
     * Retourne toutes les fiches dans l'état précisé en paramètres
     * @param $etat
     * @return tableau associatif des fiches 
     */
    public function get_fiches_etat($etat)
    {
        $this->db->select(' fichefrais.idVisiteur, 
                        mois, 
                        nom, 
                        prenom, 
                        LEFT(mois, 4) as numAnnee,
                        RIGHT(mois, 2) as numMois');
        $this->db->from('fichefrais');
        $this->db->join('visiteur ', 'visiteur.idVisiteur = fichefrais.idVisiteur');
        $this->db->where('idEtat ', $etat);
        $this->db->order_by('mois');
        $query = $this->db->get();
        return $query->result_array();  //fetchall
    }

    /**
     * Retourne toutes les fiches dans l'état précisé en paramètres
     * @param $etat
     * @return tableau associatif des fiches 
     */
    public function maj_fiches_horsforfait($montant, $idVisiteur, $mois, $id)
    {
            $data = array('montant' => $montant);
            $where = array(
                'idVisiteur' => $idVisiteur,
                'mois' => $mois,
                'idFraisHorsForfait' =>  $id
            );
            $this->db->update('lignefraishorsforfait', $data, $where);
    }

    /**
     * Modifie l'état et la date de modification d'une fiche de frais
     * Modifie le champ idEtat et met la date de modif à aujourd'hui
     * @param $idVisiteur 
     * @param $mois sous la forme aaaamm
     */
    public function refus_fraishorsforfait($idFrais)
    {
        $this->db->select('libelleFraisHorsForfait, etat')
                 ->from('lignefraishorsforfait')
                 ->where('idFraisHorsForfait', $idFrais);
        $query = $this->db->get()->result_array();
        if($query[0]['etat'] == 1) {
            $libelle = 'REFUS :'.$query[0]['libelleFraisHorsForfait'];
            $info =  "Le refus du frais hors-forfait a bien été effectuée";
        } else {
            $libelle = substr($query[0]['libelleFraisHorsForfait'],7);
            $info  = "Le retablissement du frais hors-forfait a bien été effectuée";
        }
        $data = array(
            'libelleFraisHorsForfait' => $this->security->xss_clean($libelle),
            'etat' => !$query[0]['etat']
        );
        $where = array(
            'idFraisHorsForfait' => $idFrais
        );
        $this->db->update('lignefraishorsforfait', $data, $where);
        return $info;
    }
}
